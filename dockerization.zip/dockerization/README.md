# thesis-sara
#### Commands
```sudo docker build . -t malletdocker```

```docker run -d -p 80:80 --name maller_container malletdocker```

To exec:
```docker exec maller_container python3 main.py --source data/training_data/{CORPUS}_corpus.txt --ntopic n ```

To copy:

```sudo docker cp c2a2b8503829:/data/output_models /Users/sara/PycharmProjects/diazdelser-TFG/results/output_models```