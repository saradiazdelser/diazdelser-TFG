"""
* *Mallet Trainer*

Class that serves as a wrapper for the training of an LDA-Mallet model.

.. codeauthor:: Jerónimo Arenas-García (jarenas@ing.uc3m.es),
              Lorena Calvo-Bartolomé
"""
import configparser
import logging
import pathlib
import sys

import numpy as np
import regex as javare
from gensim.utils import check_output
from scipy import sparse
from sklearn.preprocessing import normalize

from src.utils import file_lines


class MalletTrainer(object):
    def __init__(self, config_file, model_folder):
        """Constructor method

        :param config_file: Path to the configuratio file nwhich the parameters for preprocessing, training and postprocessing are read
        :type config_file: pathlib.Path
        :param model_folder: Folder in which the model to be trained will be saved
        :type model_folder: pathlib.Path
        """

        # Configure logger object
        logging.basicConfig(level='INFO')
        self.logger = logging.getLogger('Starting Mallet Trainer')

        # Configuration object
        self.cf = configparser.ConfigParser()
        self.cf.read(config_file)

        # Output model folder
        self.model_folder = model_folder
        if not self.model_folder.is_dir():
            self.logger.error(
                f'-- -- Provided model folder is not valid -- Stop')
            sys.exit()

        # Read settings for Mallet training from config file
        self._token_regexp_str = self.cf['Training']['token_regexp']
        self._token_regexp = javare.compile(
            self.cf['Training']['token_regexp'])
        self._mallet_path = pathlib.Path(self.cf['Training']['mallet_path'])
        if not self._mallet_path.is_file():
            self.logger.error(
                f'-- -- Provided mallet path is not valid -- Stop')
            sys.exit()
        self._numTopics = int(self.cf['Training']['ntopics'])
        self._alpha = float(self.cf['Training']['alpha'])
        self._optimizeInterval = int(self.cf['Training']['optimize_interval'])
        self._numThreads = int(self.cf['Training']['num_threads'])
        self._numIterations = int(self.cf['Training']['num_iterations'])
        self._docTopicsThreshold = float(self.cf['Training']['doc_topic_thr'])
        self._sparse_thr = float(self.cf['Training']['thetas_thr'])

        # Training file for the corpus
        f = self.cf['Training']['training_file']
        if pathlib.Path(f).is_file():
            self._corpus_file = pathlib.Path(f)
        else:
            self.logger.error(
                f'-- -- Corpus file {f} does not exist -- Stop')
            sys.exit()
        self.logger.info(
            f'-- -- Initialization of MalletTrainer variables completed')

    def _prepare(self):
        """It transforms the training data into the training format required for mallet by assuming that the training corpus is provided in a single file containing one document per line. This file needs to follow the Mallet format, that is:
        - the first token on each line, which is whitespace delimited (with an optional comma), is the instance name
        - the second toke is the label
        - all additional text is interpreted as a sequence of word tokens.
        """

        # Import data to mallet
        self.logger.info('-- -- Mallet Corpus Generation: Mallet Data Import')

        # Path to the mallet corpus is going to be saved
        corpus_mallet = self.model_folder.joinpath('training_data.mallet')

        # Invoke mallet import command
        cmd = self._mallet_path.as_posix() + \
            ' import-file --preserve-case --keep-sequence ' + \
            '--remove-stopwords --token-regex "' + self._token_regexp_str + \
            '" --input %s --output %s'
        cmd = cmd % (self._corpus_file, corpus_mallet)

        try:
            self.logger.info(f'-- -- Running command {cmd}')
            check_output(args=cmd, shell=True)
        except:
            self.logger.error(
                '-- -- Mallet failed to import data. Revise command')

        return

    def _train(self):
        """It trains a Mallet model using the settings specified in the configuration file given to the MalletTrainer object.
        It sparsifies the thetas matrix and saves the models' matrices (alphas, betas, and thetas) in the model's folder.
        Additionally, it gets the topics' chemical descriptions for a default number of 15 words describing each topic.
        """

        # Get paths to the training configuration and training data
        config_file = self.model_folder.joinpath('mallet.config')
        corpus_mallet = self.model_folder.joinpath('training_data.mallet')

        # Create folder for storing results for mallet training
        self.model_folder.joinpath('mallet_output').mkdir()

        # Save configuration for mallet training in config file inside the model's folder
        with config_file.open('w', encoding='utf8') as fout:
            fout.write('input = ' + corpus_mallet.as_posix() + '\n')
            fout.write('num-topics = ' + str(self._numTopics) + '\n')
            fout.write('alpha = ' + str(self._alpha) + '\n')
            fout.write('optimize-interval = ' +
                       str(self._optimizeInterval) + '\n')
            fout.write('num-threads = ' + str(self._numThreads) + '\n')
            fout.write('num-iterations = ' + str(self._numIterations) + '\n')
            fout.write('doc-topics-threshold = ' +
                       str(self._docTopicsThreshold) + '\n')
            fout.write('output-doc-topics = ' + self.model_folder.joinpath(
                'mallet_output').joinpath('doc-topics.txt').as_posix() + '\n')
            fout.write('word-topic-counts-file = ' + self.model_folder.joinpath(
                'mallet_output').joinpath('word-topic-counts.txt').as_posix() + '\n')
            fout.write('diagnostics-file = ' + self.model_folder.joinpath(
                'mallet_output').joinpath('diagnostics.xml ').as_posix() + '\n')
            fout.write('xml-topic-report = ' + self.model_folder.joinpath(
                'mallet_output').joinpath('topic-report.xml').as_posix() + '\n')
            fout.write('output-topic-keys = ' + self.model_folder.joinpath(
                'mallet_output').joinpath('topickeys.txt').as_posix() + '\n')
            fout.write('inferencer-filename = ' + self.model_folder.joinpath(
                'mallet_output').joinpath('inferencer.mallet').as_posix() + '\n')

        # Execute mallet training command
        cmd = str(self._mallet_path) + \
            ' train-topics --config ' + str(config_file)

        try:
            self.logger.info(
                f'-- -- Training mallet topic model. Command is {cmd}')
            check_output(args=cmd, shell=True)
        except:
            self.logger.error('-- -- Model training failed. Revise command')
            return

        # Get thetas matrix
        thetas_file = self.model_folder.joinpath(
            'mallet_output').joinpath('doc-topics.txt')

        cols = [k for k in np.arange(2, self._numTopics + 2)]

        # Sparsification of thetas matrix
        self.logger.debug('-- -- Sparsifying doc-topics matrix')
        thetas32 = np.loadtxt(thetas_file, delimiter='\t',
                              dtype=np.float32, usecols=cols)

        # Set to zeros all thetas below threshold, and renormalize
        thetas32[thetas32 < self._sparse_thr] = 0
        thetas32 = normalize(thetas32, axis=1, norm='l1')
        self.thetas = sparse.csr_matrix(thetas32, copy=True)

        # Recalculate topic weights (importance) to avoid errors due to sparsification
        self.alphas = np.asarray(np.mean(thetas32, axis=0)).ravel()

        # Create vocabulary files and calculate beta matrix
        wtcFile = self.model_folder.joinpath(
            'mallet_output').joinpath('word-topic-counts.txt')
        vocab_size = file_lines(wtcFile)
        self.betas = np.zeros((self._numTopics, vocab_size))
        vocab = []
        term_freq = np.zeros((vocab_size,))

        self.vocab_id2w = {}
        with wtcFile.open('r', encoding='utf8') as fin:
            for i, line in enumerate(fin):
                elements = line.split()
                vocab.append(elements[1])
                self.vocab_id2w[str(i)] = elements[1]
                for counts in elements[2:]:
                    tpc = int(counts.split(':')[0])
                    cnt = int(counts.split(':')[1])
                    self.betas[tpc, i] += cnt
                    term_freq[i] += cnt
        self.betas = normalize(self.betas, axis=1, norm='l1')

        # Save vocabulary and frequencies
        with self.model_folder.joinpath('vocab_freq_mallet.txt').open('w', encoding='utf8') as fout:
            [fout.write(el[0] + '\t' + str(int(el[1])) + '\n')
             for el in zip(vocab, term_freq)]
        self.logger.debug('-- -- Mallet training: Vocabulary file generated')

        # Get topic descriptions
        self.topic_word_descrption = self.get_topic_word_descriptions()

        # Save the model for future use
        modelVarsDir = self.model_folder.joinpath('model_vars')
        modelVarsDir.mkdir()
        np.save(modelVarsDir.joinpath('alphas.npy'), self.alphas)
        np.save(modelVarsDir.joinpath('betas.npy'), self.betas)
        np.savez(modelVarsDir.joinpath('thetas.npz'),
                 thetas_data=self.thetas.data, thetas_indices=self.thetas.indices,
                 thetas_indptr=self.thetas.indptr, thetas_shape=self.thetas.shape)
        with open(self.model_folder.joinpath('mallet_output').joinpath('topic-word-descriptions.txt'), 'w') as f:
            [f.write(','.join([str(top) for top in topic])+'\n') for topic in self.topic_word_descrption]

        # Remove doc-topics file. It is no longer needed and takes a lot of space
        #thetas_file.unlink()

        return

    def fit(self):
        """It fits the model, i.e. preprocess training data and carry out the training itself.
        """
        self._prepare()
        self._train()

    def get_topic_word_descriptions(self, n_words=15, tpc=None):
        """It gets a list with the chemical description for each of the topics attained after the training of a topic model.

        :param n_words: Number of words to describe each topic, defaults to 15
        :type n_words: int, optional
        :param tpc: list with the topic whose chemical description is going to be obtained, i.e., if not None, the descriptions of the topics with id within the list opc are returned e.g.: tpc = [0,3,4], defaults to None
        :type tpc: list, optional
        :return: List with the topics' chemical description
        :rtype: list
        """

        if not tpc:
            tpc = range(self._numTopics)
        tpc_descs = []
        for i in tpc:
            words = [self.vocab_id2w[str(idx2)]
                     for idx2 in np.argsort(self.betas[i])[::-1][0:n_words]]
            tpc_descs.append((i, ', '.join(words)))

        return tpc_descs
