def file_lines(fname):
    """Counts the number of lines in a file

    :param fname: Path to the file whose lines are being count
    :type fname: pathlib.Path
    :return: The number of lines in the given file
    :rtype: int
    """    
    # Count number of lines in file
    with fname.open('r', encoding='utf8') as f:
        for i, l in enumerate(f):
            pass
    return i + 1