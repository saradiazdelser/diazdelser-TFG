"""
* *Main script*

.. codeauthor:: Lorena Calvo-Bartolomé
"""
import argparse
import configparser
import logging
import os
import pathlib
import shutil

from src.mallet_trainer import MalletTrainer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=str, default="data/training_data/training_data.txt",
                        help="File with  .")
    parser.add_argument('--ntopics', type=int, default=10,
                        help="Number of topics to train the model with.")
    args = parser.parse_args()

    # Create logger object
    logging.basicConfig(level='INFO')
    logger = logging.getLogger('Logger')

    # Load configuration file
    cf = configparser.ConfigParser()
    cf.read("config.cf.default")

    # Read default values from config file
    token_regexp = cf.get('mallet', 'token_regexp')
    mallet_path = cf.get('mallet', 'mallet_path')
    alpha = float(cf.get('mallet', 'alpha'))
    optimize_interval = int(cf.get('mallet', 'optimize_interval'))
    num_threads = int(cf.get('mallet', 'num_threads'))
    num_iterations = int(cf.get('mallet', 'num_iterations'))
    doc_topic_thr = float(cf.get('mallet', 'doc_topic_thr'))
    thetas_thr = float(cf.get('mallet', 'thetas_thr'))
    n_topics = args.ntopics if args.ntopics is not None else int(
        cf.get('mallet', 'n_topics'))

    # Create folder for corpus, backup existing folder if necessary
    modelname = "lda_mallet_model_" + str(n_topics)
    modeldir = pathlib.Path('data/output_models').joinpath(modelname)
    logger.info(
        f'-- -- The model folder is {modeldir.as_posix()}.')

    if modeldir.exists():
        # Remove current backup folder, if it exists
        old_model_dir = pathlib.Path(str(modeldir) + '_old/')
        if old_model_dir.exists():
            shutil.rmtree(old_model_dir)

        # Copy current project folder to the backup folder.
        shutil.move(modeldir, old_model_dir)

    # Create corpus_folder and save model training configuration
    os.makedirs(modeldir)
    configFile = modeldir.joinpath('train.config')
    with configFile.open('w', encoding='utf8') as fout:
        fout.write('\n[Training]\n')
        fout.write('trainer = mallet\n')
        fout.write('token_regexp = ' + str(token_regexp) + '\n')
        fout.write('mallet_path = ' + mallet_path + '\n')
        fout.write('ntopics = ' + str(n_topics) + '\n')
        fout.write('alpha = ' + str(alpha) + '\n')
        fout.write('optimize_interval = ' + str(optimize_interval) + '\n')
        fout.write('num_threads = ' + str(num_threads) + '\n')
        fout.write('num_iterations = ' + str(num_iterations) + '\n')
        fout.write('doc_topic_thr = ' + str(doc_topic_thr) + '\n')
        fout.write('thetas_thr = ' + str(thetas_thr) + '\n')
        fout.write('training_file = ' + args.source + '\n')

    # Create trainer
    mallet_trainer = MalletTrainer(configFile, model_folder=configFile.parent)
    mallet_trainer.fit()


if __name__ == "__main__":
    main()
